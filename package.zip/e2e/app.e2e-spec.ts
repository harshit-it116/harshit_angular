import { HarshitAngular2SmartTablePage } from './app.po';

describe('harshit-angular2-smart-table App', function() {
  let page: HarshitAngular2SmartTablePage;

  beforeEach(() => {
    page = new HarshitAngular2SmartTablePage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
