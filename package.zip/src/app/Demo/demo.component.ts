import { Component, OnInit } from '@angular/core';
import { Ng2SmartTableModule, ServerDataSource } from 'ng2-smart-table';
 
import { Http } from '@angular/http/src/http';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})



export class DemoComponent {

  settings = {
    columns: {
      id: {
        title: 'ID'
      },
      albumId: {
        title: 'Album'
      },
      title: {
        title: 'Title'
      },
      url: {
        title: 'Url'
      }
    }
  };

  source: ServerDataSource;
  
  constructor(http: Http) {
    this.source = new ServerDataSource(http, {endPoint: 'https://jsonplaceholder.typicode.com/photos'});
  }
}
