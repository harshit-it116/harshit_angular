import { BrowserModule } from '@angular/platform-browser';
import { HttpModule } from '@angular/http';

import { NgModule } from '@angular/core';

 import { routing } from './app.routes';

import {Ng2SmartTableModule} from 'ng2-smart-table';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
 import { DataComponent } from './data/data.component';
import { FooterComponent } from './footer/footer.component';
 import { DemoComponent } from './Demo/demo.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
   DataComponent,
    FooterComponent,
    DemoComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    Ng2SmartTableModule,
    routing
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
