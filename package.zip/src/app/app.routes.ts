import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DemoComponent } from './Demo/demo.component';
import { DataComponent } from './data/data.component';


const routes: Routes = [
  {path: '', component: DataComponent, pathMatch : 'full'},
  {path: 'demo', component: DemoComponent}
  
];

export const routing: ModuleWithProviders = RouterModule.forRoot(routes);
